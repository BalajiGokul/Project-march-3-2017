package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DatabaseConnection;
import bean.SignupBean;

public class SignupDao {
	public SignupDao() throws ClassNotFoundException, SQLException {
	}

	public boolean signupDao(SignupBean signupBean)
			throws ClassNotFoundException, SQLException {
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		String query = "";
		query = "select mobile_number from requests";
		ps = c.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		query = "select mobile_number from login_details";
		ps = c.prepareStatement(query);
		ResultSet rs1 = ps.executeQuery();
		int availability = 0;
		while (rs.next()) {
			if (rs.getString(1).equals(signupBean.getMobile_number())) {
				availability++;
				System.out.println(availability + " request");
			}
		}
		while (rs1.next()) {
			if (rs1.getString(1).equals(signupBean.getMobile_number())) {
				availability++;
				System.out.println(availability + " login");
			}
		}
		System.out.println(availability);
		if (availability > 0) {
			return false;
		}
		if (signupBean.getUser().equals("Buyer")) {
			query = "insert into buyer_details (name,password,email_id,mobile_number,birthday) values (?,?,?,?,?)";
			ps = c.prepareStatement(query);
			ps.setString(1, signupBean.getName());
			ps.setString(2, signupBean.getPassword());
			ps.setString(3, signupBean.getMail_id());
			ps.setString(4, signupBean.getMobile_number());
			ps.setString(5, signupBean.getBirthday());
			ps.execute();
			query = "";
			query = "insert into login_details (mobile_number,password,user_type) values (?,?,?)";
			ps = c.prepareStatement(query);
			ps.setString(1, signupBean.getMobile_number());
			ps.setString(2, signupBean.getPassword());
			ps.setString(3, signupBean.getUser());
			ps.execute();
		} else if (signupBean.getUser().equals("Advisor")) {
			query = "insert into requests (name,password,email_id,mobile_number,birthday,degree,userType) values (?,?,?,?,?,?,?)";
			ps = c.prepareStatement(query);
			ps.setString(1, signupBean.getName());
			ps.setString(2, signupBean.getPassword());
			ps.setString(3, signupBean.getMail_id());
			ps.setString(4, signupBean.getMobile_number());
			ps.setString(5, signupBean.getBirthday());
			ps.setString(6, signupBean.getDegree());
			ps.setString(7, "Advisor");
			ps.execute();
			/*
			 * query=""; query=
			 * "insert into login_details (mobile_number,password,user_type) values (?,?,?)"
			 * ; ps = c.prepareStatement(query); ps.setString(1,
			 * signupBean.getMobile_number()); ps.setString(2,
			 * signupBean.getPassword()); ps.setString(3,signupBean.getUser());
			 * ps.execute();
			 */
		} else if (signupBean.getUser().equals("Seller")) {
			query = "insert into requests (name,password,email_id,mobile_number,birthday,userType) values (?,?,?,?,?,?)";
			ps = c.prepareStatement(query);
			ps.setString(1, signupBean.getName());
			ps.setString(2, signupBean.getPassword());
			ps.setString(3, signupBean.getMail_id());
			ps.setString(4, signupBean.getMobile_number());
			ps.setString(5, signupBean.getBirthday());
			ps.setString(6, "Seller");
			ps.execute();
			/*
			 * query=""; query=
			 * "insert into login_details (mobile_number,password,user_type) values (?,?,?)"
			 * ; ps = c.prepareStatement(query); ps.setString(1,
			 * signupBean.getMobile_number()); ps.setString(2,
			 * signupBean.getPassword()); ps.setString(3,signupBean.getUser());
			 * ps.execute();
			 */
		}
		return true;
	}
}
