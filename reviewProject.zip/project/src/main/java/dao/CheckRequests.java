package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DatabaseConnection;

public class CheckRequests {
	public boolean AdvisorRequests() throws ClassNotFoundException,
			SQLException {
		Connection connection = DatabaseConnection.getDB();
		PreparedStatement preparestatement = null;
		String query = "select count(*) from requests where userType = ?";
		preparestatement = connection.prepareStatement(query);
		preparestatement.setString(1, "Advisor");
		ResultSet resultset = preparestatement.executeQuery();
		resultset.next();
		if (resultset.getInt(1) == 0) {
			return false;
		} else {
			return true;
		}
	}

	public boolean SellerRequests() throws ClassNotFoundException, SQLException {
		Connection connection = DatabaseConnection.getDB();
		PreparedStatement preparestatement = null;
		String query = "select count(*) from requests where userType = ?";
		preparestatement = connection.prepareStatement(query);
		preparestatement.setString(1, "Seller");
		ResultSet resultset = preparestatement.executeQuery();
		resultset.next();
		if (resultset.getInt(1) == 0) {
			return false;
		} else {
			return true;
		}
	}

}
