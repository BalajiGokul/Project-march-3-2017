package dao;

import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import rowMapper.jdbcRowMapper;
import bean.viewUser;

@Component
public class jdbcUserDao extends JdbcDaoSupport {

	@Autowired
	public jdbcUserDao(DataSource dataSource) {
		setDataSource(dataSource);
	}

	public ArrayList<viewUser> getUsersDao(String user)
			throws ClassNotFoundException {
		ArrayList<viewUser> UsersList = new ArrayList<viewUser>();
		if (user.equals("Buyers")) {
			UsersList = (ArrayList<viewUser>) getJdbcTemplate().query(
					"Select * from buyer_details", new Object[] {},
					new jdbcRowMapper());
		} else if (user.equals("Advisor")) {
			UsersList = (ArrayList<viewUser>) getJdbcTemplate().query(
					"Select * from advisor_details", new Object[] {},
					new jdbcRowMapper());
		} else if (user.equals("Seller")) {
			UsersList = (ArrayList<viewUser>) getJdbcTemplate().query(
					"Select * from seller_details", new Object[] {},
					new jdbcRowMapper());
		}
		return UsersList;

	}
}
