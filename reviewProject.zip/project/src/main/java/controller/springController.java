package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import bean.ProductBean;
import bean.viewUser;
import dao.ViewProductsDao;
import dao.jdbcUserDao;

@RestController
@RequestMapping(value = "/products")
public class springController {

	@Autowired
	jdbcUserDao jdbcuserdao;

	@RequestMapping(value = "/getBuyers", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<viewUser> getBuyers() throws SQLException,
			ClassNotFoundException {
		List<viewUser> li = (ArrayList<viewUser>) jdbcuserdao
				.getUsersDao("Buyers");
		return li;
	}

	@RequestMapping(value = "/getAdvisor", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<viewUser> getAdvisor() throws SQLException,
			ClassNotFoundException {
		List<viewUser> li = (ArrayList<viewUser>) jdbcuserdao
				.getUsersDao("Advisor");
		return li;
	}

	@RequestMapping(value = "/getSeller", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<viewUser> getSEeller() throws SQLException,
			ClassNotFoundException {
		List<viewUser> li = (ArrayList<viewUser>) jdbcuserdao
				.getUsersDao("Seller");
		return li;
	}

	@RequestMapping(value = "/getProducts", method = RequestMethod.GET)
	public List<ProductBean> getAllProduct() throws ClassNotFoundException,
			SQLException {
		ViewProductsDao viewproductdao = new ViewProductsDao();
		List<ProductBean> productsAvailable = viewproductdao.getProductsDao();
		return productsAvailable;

	}

}

/*
 * @RestController
 * 
 * @RequestMapping(value = "/products") public class springController {
 * 
 * }
 */