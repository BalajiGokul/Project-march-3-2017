package services;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.SignupBean;
import dao.SignupDao;

public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Signup() {
		super();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		SignupBean signupBean = new SignupBean();
		signupBean.setName(request.getParameter("name"));
		signupBean.setPassword(request.getParameter("password"));
		signupBean.setMail_id(request.getParameter("mail_id"));
		signupBean.setMobile_number(request.getParameter("mobile_number"));
		signupBean.setBirthday(request.getParameter("birthday"));
		signupBean.setDegree(request.getParameter("degree"));
		HttpSession session = request.getSession();
		String currentuser = (String) session.getAttribute("type");
		signupBean.setUser(currentuser);
		SignupDao sd = null;
		boolean status = false;
		try {
			sd = new SignupDao();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			status = sd.signupDao(signupBean);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status == false) {
			RequestDispatcher home = request
					.getRequestDispatcher("/SignupFailed.jsp");
			home.forward(request, response);
		} else {
			if (currentuser.equals("Buyer")) {
				RequestDispatcher login = request
						.getRequestDispatcher("/HomePage.jsp");
				login.forward(request, response);
			} else {
				RequestDispatcher login = request
						.getRequestDispatcher("/RequestConfirmation.jsp");
				login.forward(request, response);
			}

		}
	}
}