package interfacePacakge;

import java.util.List;

import javax.sql.DataSource;

import bean.ProductBean;
import bean.SignupBean;
import bean.ViewMailBean;
import bean.viewAdvisor;
import bean.viewUser;

public interface ProjectInterfaces {
	public void AddProductDao(ProductBean productbean); 
	public void AddToCart(String product_id, String mobile_number);
	public boolean AdvisorRequests();
	public boolean SellerRequests();
	public void jdbcUserDao(DataSource dataSource);
	public boolean signupDao(SignupBean signupBean);
	public List<viewAdvisor> getUsers();
	public List<ProductBean> getCart(String mobile_number);
	public List<ViewMailBean> getMails(String action,String mobile_number);
	public List<ProductBean> getProductsDao(String mobile_number);
	public List<ProductBean> getProductsDao() ;
	public List<viewUser> getUsers(String userType);
	
	
}
