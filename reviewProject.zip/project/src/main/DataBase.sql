create table buyer_details (name varchar(25),password varchar(25),email_id varchar(25),mobile_number varchar(14) primary key ,birthday date);
select * from buyer_details;
truncate table buyer_details;
drop table buyer_details;

create table advisor_details (name varchar(25),password varchar(25),email_id varchar(25),mobile_number varchar(14) primary key ,birthday date,degree varchar(25));
select * from advisor_details;
truncate table advisor_details;
drop table advisor_details;

delete from ADVISOR_DETAILS where mobile_number='9876543210';

create table seller_details (name varchar(25),password varchar(25),email_id varchar(25),mobile_number varchar(14) primary key ,birthday date);
select * from seller_details;
truncate table seller_details;
drop table seller_details;

create table login_details (password varchar(25),mobile_number varchar(14) primary key,user_type varchar(10));
select * from login_details;
truncate table login_details;
drop table login_details;

delete from login_details where password = '7373499407';

create table admin_details(username varchar(25),password varchar(25));
insert into admin_details(username,password) values ('admin','AdMiN');
insert into admin_details(username,password) values ('admin2','admin');
select * from admin_details;
truncate table admin_details;
drop table admin_details;
delete from ADMIN_DETAILS where password = 'admin';

create table products (product_id varchar(10),name varchar(50),price varchar(10),quantity varchar(10),description varchar(10000),seller varchar(25),mobile_number varchar(14));
select * from products;
drop table products;

CREATE sequence product_id AS int start WITH 1;
DROP SEQUENCE product_id RESTRICT;


create table temp (id int);
truncate table temp;
select * from temp;
drop table temp; 


create table product_convention(product_name varchar(30),product_id varchar(10) primary key,admin_name varchar(25));
select * from PRODUCT_CONVENTION;
truncate table product_convention;
drop table product_convention;

CREATE sequence autogen AS int start WITH 1;
DROP SEQUENCE autogen RESTRICT;



create table feedbackid (id int);
truncate table feedbackid;
select * from feedbackid;
drop table feedbackid; 

create table feedback (id varchar(10),hugsbugs varchar(10000));
select * from feedback;
truncate table feedback;
drop table feedback;

create table sentmail (id varchar(10),sender varchar(25),receiver varchar(25),subject varchar(1000),message varchar(10000));
select * from sentmail;
truncate table sentmail;
drop table sentmail;

create table receivedmail (id varchar(10),sender varchar(25),receiver varchar(25),subject varchar(1000),message varchar(10000));
insert into receivedmail (id,sender,receiver,subject,message) values ('7','9842573314','9445835314','Reply Test','Reply this message');
select * from receivedmail;
truncate table receivedmail;
drop table receivedmail;



CREATE sequence mailid AS int start WITH 1;
DROP SEQUENCE mailid RESTRICT;


CREATE sequence cartid AS int start WITH 1;
DROP SEQUENCE cartid RESTRICT;



create table pics (name varchar(20),img blob(16M));
select * from pics;


create table requests (name varchar(25),password varchar(25),email_id varchar(25),mobile_number varchar(14) primary key ,birthday date,degree varchar(25),userType varchar(10),status varchar(10));
select * from requests;
truncate requests;
drop requests;


create table cart (cart_id varchar(10),product_id varchar(10),name varchar(50),price varchar(10),quantity varchar(10),description varchar(10000),seller varchar(25),mobile_number varchar(14));
select * from cart;
truncate table cart;
drop table cart;

select count(*) from requests where userType = 'Advisor';
