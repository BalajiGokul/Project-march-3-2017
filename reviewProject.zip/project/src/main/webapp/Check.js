function validatePhoneNumber(inputtxt)
{
  var phoneno = /^\d{10}$/;
  if((inputtxt.value.match(phoneno)))
        {
      return true;
        }
      else
        {
       		alert("Invalid Phone Number\nPlease enter the valid number");
        	return false;
        }
}
function CheckPassword(inputtxt) 
{ 
	var passw =  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
	if(inputtxt.value.match(passw)) 
	{ 
		return true;
	}
	else
	{ 
		alert('Invalid Password\nMust contain the following:\n1)Numeric\n2)Alphabets\n3)Special Character\neg:pass@123');
		return false;
	}
}
